Build
-----
ndk-build NDK_DEBUG=1
ant debug

Install
-------
adb install -r dalvik_api17_hellojni.apk

Run
---
adb shell am start -a android.intent.action.MAIN -n ida.debug.hellojni/.MainActivity


Clean
-----
ndk-build clean
ant clean
