#include <stdio.h>
#include <jni.h>

jstring Java_ida_debug_hellojni_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject thiz)
{
  return (*env)->NewStringUTF(env, "Hello, JNI world!");
}
