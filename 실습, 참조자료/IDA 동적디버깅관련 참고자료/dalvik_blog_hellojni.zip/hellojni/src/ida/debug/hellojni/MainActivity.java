package ida.debug.hellojni;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

import android.widget.LinearLayout;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;

public class MainActivity extends Activity {
        public native String stringFromJNI();

        static {
                System.loadLibrary("hello-jni");
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);

                final TextView tv = new TextView(this);

                final Button btn = new Button(this);
                btn.setText("Press me to call the native code");
                btn.setOnClickListener(new Button.OnClickListener() {
                        public void onClick(View v) {
                                tv.setText(stringFromJNI());
                        }
                });

                LinearLayout layout = new LinearLayout(this);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
                                LayoutParams.FILL_PARENT));
                layout.addView(btn);
                layout.addView(tv);

                setContentView(layout);
        }
}
