/** Automatically generated file. DO NOT MODIFY */
package com.namdaehyeon.helloexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}