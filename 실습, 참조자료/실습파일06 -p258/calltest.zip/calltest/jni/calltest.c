/*
 * by namdaehyeon (nam_daehyeon@naver.com) 
 */

#include <stdio.h>
#include <dlfcn.h> 

int main(int argc, char* argv[]) {
	const char *lib = "/data/local/tmp/libhello-jni.so";
	const char *jniMethodName = "Java_ida_debug_hellojni_MainActivity_stringFromJNI";

	void *handle = dlopen(lib, RTLD_LAZY);

	typedef void (*aFunc)();
	
	aFunc aCheckDebug = (aFunc) dlsym(handle, jniMethodName);

	printf("[+] Call jni function!!\n");

	//call jni func
	aCheckDebug();

	printf("dlclose(handle)\n");
	dlclose(handle);

	return 0;
}
